<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $Name = isset($_POST['Name']) ? $_POST['Name'] : "";
    $Email = isset($_POST['Email']) ? $_POST['Email'] : "";
    $PhoneNumber = isset($_POST['PhoneNumber']) ? $_POST['PhoneNumber'] : "";
    $Message = isset($_POST['Message']) ? $_POST['Message'] : "";
    
    // Process the data further (e.g., database insertion, email sending, etc.)
    // Your database insertion code goes here
}



$conn = new mysqli('localhost', 'root', '', 'Contact');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into Contact (Name, Email, PhoneNumber, Message) values (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $Name,  $Email, $PhoneNumber, $Message);
    $stmt->execute();
    echo "Registration Successful.....";
    $stmt->close();
    $conn->close();

    
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
</head>
<body>
    <?php if (!empty($message)) { ?>
        
        <a href="index.html">Main Page</a>
    <?php } else { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Your form fields go here -->
            <input type="submit" value="Submit">
        </form>
    <?php } ?>
</body>
</html>